const filters = [...document.querySelectorAll('[data-filter]')];
const cards = [...document.querySelectorAll('.catalog-card')];
const search = document.querySelector('#search');
let current = 'all';
function applyFilters() {
  const query = search.value.trim().toLocaleLowerCase('ru');
  let count = 0;
  for(const card of cards) {
    const visible = (current === 'all' || card.dataset.city === current) && card.dataset.search.includes(query);
    card.hidden = !visible;
    if(visible) count += 1;
  }
  document.querySelector('.catalog-count').textContent = `Показано компаний: ${count}`;
  document.querySelector('.empty').hidden = count > 0;
}
filters.forEach(button => button.addEventListener('click',() => {
  current = button.dataset.filter;
  filters.forEach(item => { item.classList.toggle('active',item === button); item.setAttribute('aria-pressed',String(item === button)); });
  applyFilters();
}));
search.addEventListener('input',applyFilters);
