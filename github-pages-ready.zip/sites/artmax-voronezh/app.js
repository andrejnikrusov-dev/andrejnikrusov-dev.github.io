const menuButton = document.querySelector('.menu-button');
const navigation = document.querySelector('#navigation');
const closeMenu = () => { menuButton.setAttribute('aria-expanded','false'); menuButton.setAttribute('aria-label','Открыть меню'); navigation.classList.remove('is-open'); };
menuButton.addEventListener('click', () => { const open = menuButton.getAttribute('aria-expanded') !== 'true'; menuButton.setAttribute('aria-expanded',String(open)); menuButton.setAttribute('aria-label',open ? 'Закрыть меню' : 'Открыть меню'); navigation.classList.toggle('is-open',open); });
navigation.querySelectorAll('a').forEach(link => link.addEventListener('click',closeMenu));
document.addEventListener('keydown', event => { if(event.key === 'Escape' && menuButton.getAttribute('aria-expanded') === 'true') { closeMenu(); menuButton.focus(); } });
const briefDialog = document.querySelector('#brief-dialog');
const photoDialog = document.querySelector('#photo-dialog');
const description = document.querySelector('#project-description');
const copyStatus = document.querySelector('#copy-status');
const openDialog = dialog => { dialog.showModal(); document.body.classList.add('no-scroll'); };
for(const dialog of [briefDialog,photoDialog]) {
  dialog.querySelector('.dialog-close').addEventListener('click',() => dialog.close());
  dialog.addEventListener('close',() => document.body.classList.remove('no-scroll'));
  dialog.addEventListener('click',event => { if(event.target !== dialog) return; const box = dialog.getBoundingClientRect(); if(event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) dialog.close(); });
}
document.querySelectorAll('.image-open,.gallery-open').forEach(button => button.addEventListener('click',() => { const image = photoDialog.querySelector('img'); image.src = button.dataset.photo || button.querySelector('img').getAttribute('src'); image.alt = button.querySelector('img').alt; photoDialog.querySelector('p').textContent = button.dataset.caption || 'ИИ-визуализация для демо · не работа компании'; openDialog(photoDialog); }));
document.querySelector('#compose-brief').addEventListener('click',() => {
  const project = document.querySelector('#project-form');
  const kind = project.querySelector('input[name="kind"]:checked').value;
  const size = project.querySelector('input[name="size"]').value.trim();
  const notes = project.querySelector('input[name="notes"]').value.trim();
  description.value = ['Здравствуйте! Хочу обсудить проект мебели.',`Что планирую: ${kind}.`,size ? `Примерные размеры: ${size}.` : '',notes ? `Пожелания: ${notes}` : '', 'Подскажите, какую информацию подготовить для расчёта?'].filter(Boolean).join('\n');
  copyStatus.textContent = '';
  openDialog(briefDialog);
});
document.querySelector('#copy-brief').addEventListener('click',async () => {
  try {
    if(navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(description.value);
    else { description.focus(); description.select(); if(!document.execCommand('copy')) throw new Error('clipboard unavailable'); }
    copyStatus.textContent = 'Описание скопировано. Можно отправить его компании.';
  } catch { description.focus(); description.select(); copyStatus.textContent = 'Выделили текст. Скопируйте его вручную.'; }
});
